<?php
//for name
include("askagain.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    <title>Dashboard</title>
    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
            
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
        color: white;
        }
        .arkaplan {width: 76.5%; height: 116.5%;  position: absolute; top: 22.3%; left:0.55%}
        .hov:hover { opacity: 1;}
        #rquad {width: 5%; height: 25%; position: absolute; top: 71.3%; left: 24.5%; opacity: 0;}
        #rquad:hover { opacity: 1;}
        #lquad {width: 5%; height: 25%; position: absolute; top: 71.3%; left: 18.6%; opacity: 0;}
        #lquad:hover { opacity: 1;}
        #lkalf {width: 3.5%; height: 20.5%; position: absolute; top: 98.0%; left: 18.25%; opacity: 0;}
        #lkalf:hover { opacity: 1;}
        #rkalf {width: 3.5%; height: 20.5%; position: absolute; top: 98.1%; left: 26.4%; opacity: 0;}
        #rkalf:hover { opacity: 1;}
        #karın {width: 5%; height: 13%; position: absolute; top: 55.7%; left: 21.5%; opacity: 0;}
        #karın:hover { opacity: 1;}
        #rbiceps {width: 3.1%; height: 10.5%; position: absolute; top: 53.75%; left: 28.6%; opacity: 0;}
        #rbiceps:hover { opacity: 1;}
        #lbiceps {width: 3.1%; height: 10.5%; position: absolute; top: 53.75%; left: 16.5%; opacity: 0;}
        #lbiceps:hover { opacity: 1;}
        #chest {width: 10%; height: 8.3%; position: absolute; top: 47.9%; left: 19.1%; opacity: 0;}
        #chest:hover { opacity: 1;}
        #rshoulder {width: 4.3%; height: 8.0%; position: absolute; top: 46.9%; left: 26.6%; opacity: 0;}
        #rshoulder:hover { opacity: 1;}
        #lshoulder {width: 4.3%; height: 8.0%; position: absolute; top: 46.9%; left: 17.25%; opacity: 0;}
        #lshoulder:hover { opacity: 1;}
        #rtrapez {width: 2.58%; height: 5%; position: absolute; top: 42.7%; left: 24.6%; opacity: 0;}
        #rtrapez:hover { opacity: 1;}
        #ltrapez {width: 2.58%; height: 5%; position: absolute; top: 42.7%; left: 21.0%; opacity: 0;}
        #ltrapez:hover { opacity: 1;}
        #trapez {width: 5.36%; height: 4.27%; position: absolute; top: 40.3%; left: 52.05%; opacity: 0;}
        #trapez:hover { opacity: 1;}
        #sırt {width: 6.22%; height: 17.33%; position: absolute; top: 43.25%; left: 51.7%; opacity: 0;}
        #sırt:hover { opacity: 1;}
        #lbackshoulder {width: 4.37%; height: 8.67%; position: absolute; top: 44.8%; left: 47.55%; opacity: 0;}
        #lbackshoulder:hover { opacity: 1;}
        #rbackshoulder {width: 4.37%; height: 8.67%; position: absolute; top: 44.8%; left: 57.7%; opacity: 0;}
        #rbackshoulder:hover { opacity: 1;}
        #ltriceps {width: 3.51%; height: 11.7%; position: absolute; top: 51.2%; left: 46.55%; opacity: 0;}
        #ltriceps:hover { opacity: 1;}
        #rtriceps {width: 3.51%; height: 11.7%; position: absolute; top: 51.2%; left: 59.55%; opacity: 0;}
        #rtriceps:hover { opacity: 1;}
        #llat {width: 4.63%; height: 16.13%; position: absolute; top: 53.4%; left: 50.0%; opacity: 0;}
        #llat:hover { opacity: 1;}
        #rlat {width: 4.63%; height: 16.13%; position: absolute; top: 53.4%; left: 55.0%; opacity: 0;}
        #rlat:hover { opacity: 1;}
        #kalça {width: 9.33%; height: 13.33%; position: absolute; top: 70.0%; left: 50.2%; opacity: 0;}
        #kalça:hover { opacity: 1;}
        #larkabacak {width: 5.1%; height: 24.67%; position: absolute; top: 77.6%; left: 49.3%; opacity: 0;}
        #larkabacak:hover { opacity: 1;}
        #rarkabacak {width: 5.1%; height: 24.67%; position: absolute; top: 77.7%; left: 55.2%; opacity: 0;}
        #rarkabacak:hover { opacity: 1;}
        #lcalves {width: 3.7%; height: 15.01%; position: absolute; top: 97.5%; left: 47.9%; opacity: 0;}
        #lcalves:hover { opacity: 1;}
        #rcalves {width: 3.7%; height: 15.01%; position: absolute; top: 97.35%; left: 58.0%; opacity: 0;}
        #rcalves:hover { opacity: 1;}
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a class="active" href="dashboard.php">DASHBOARD</a></li>
        <li><a href="bmi.php">BODY MASS INDEX</a></li>
        <li><a href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >  
<main>
    <div>
          <br><h3 align='right'>SELECT THJSABHDHABDHABHDBAHBSHDBAHBDE</h3>  
          <br><br><br>
        <img src="download.png" alt="" class="arkaplan">
        <a href="bacak.html"><img src="rquad.png" alt="" id="rquad" class="hov" ></a>
        <a href="bacak.html"><img src="lquad.png" alt="" id="lquad" class="hov" ></a>
        <a href="bacak.html"><img src="lkalf.png" alt="" id="lkalf" class="hov" ></a>
        <a href="bacak.html"><img src="rkalf.png" alt="" id="rkalf" class="hov" ></a>
        <a href="karin.html"><img src="karçn.png" alt="" id="karın" class="hov" ></a>
        <a href="kol.html"><img src="rbiceps.png" alt="" id="rbiceps" class="hov" ></a>
        <a href="kol.html"><img src="lbiceps.png" alt="" id="lbiceps" class="hov" ></a>
        <a href="chest.php"><img src="chest.png" alt="" id="chest" class="hov" ></a>
        <a href="omuz.html"><img src="rshoulder.png" alt="" id="rshoulder" class="hov" ></a>
        <a href="omuz.html"><img src="lshoulder.png" alt="" id="lshoulder" class="hov" ></a>
        <a href="omuz.html"><img src="rtrapez.png" alt="" id="rtrapez" class="hov" ></a>
        <a href="omuz.html"><img src="ltrapez.png" alt="" id="ltrapez" class="hov" ></a>
        <a href="omuz.html"><img src="trapez.png" alt="" id="trapez" class="hov" ></a>
        <a href="back.html"><img src="sçrt.png" alt="" id="sırt" class="hov" ></a>
        <a href="omuz.html"><img src="lbackshoulder.png" alt="" id="lbackshoulder" class="hov" ></a>
        <a href="omuz.html"><img src="rbackshoulder.png" alt="" id="rbackshoulder" class="hov" ></a>
        <a href="kol.html"><img src="ltriceps.png" alt="" id="ltriceps" class="hov" ></a>
        <a href="kol.html"><img src="rtriceps.png" alt="" id="rtriceps" class="hov" ></a>
        <a href="back.html"><img src="llat.png" alt="" id="llat" class="hov" ></a>
        <a href="back.html"><img src="rlat.png" alt="" id="rlat" class="hov" ></a>
        <a href="kalca.html"><img src="kaláa.png" alt="" id="kalça" class="hov" ></a>
        <a href="bacak.html"><img src="larkabacak.png" alt="" id="larkabacak" class="hov" ></a>
        <a href="bacak.html"><img src="rarkabacak.png" alt="" id="rarkabacak" class="hov" ></a>
        <a href="bacak.html"><img src="lcalves.png" alt="" id="lcalves" class="hov" ></a>
        <a href="bacak.html"><img src="rcalves.png" alt="" id="rcalves" class="hov" ></a>
        </div>
    </main>
    <br><br><br><br><br><br>
</div>

</body>
</html>