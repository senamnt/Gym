<html>
    <head>
        <meta charset="utf-8"/>
    <title>Connect With Us</title>

    <script></script>

    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        input, p{
            display: block;
            height: 50px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            color: white;
        }
        ::placeholder{
            color: rgba(255, 255, 255, 0.74);
        }
                .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            background: url(gym.jpg);
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            color: white;
        }
        textarea {
            display: block;
            height: 100px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            font-family: Helvetica, sans-serif;
            color: white;
        }
        h1{
            font-size: 65px;
        }
        h2{
            font-size: 27px;
        }
        .başlık {
            
            color: white;
    } 
        
        a {text-decoration: none;}
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="bmi.php">BODY MASS INDEX</a></li>
        <li><a class="active" href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >
    <table align="center">
        <tr>
            <td></td>
            <td> 
                <form action="iletişimkayıt.php" method="get">
                    <table>
                        <tr>
                            <td height="50"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" name="name" placeholder="Name" required /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" name="surname" placeholder="Surname"required > </td> 
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                            <textarea name="problem" placeholder="Please write the subject you want to connect to us."<required></textarea>
                                </td>
                                </tr>    
                                <tr>
                                    <td></td>
                                    <td><input type="submit" name="submit" value="Submit">                                        
                                    </td>
                                </tr>
                                     <tr>
                                <td></td>
                                <td><input type="reset" value="Reset"><br></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                </tr>

                                </table>
                    </div>
                                </body>
                                </html>