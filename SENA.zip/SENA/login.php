<?php
require('db.php');
session_start();
// Databasemize kaydediyoruz gelen POST'ları
if (isset($_POST['username'])) {
    $username = stripslashes($_REQUEST['username']);    // removes backslashes
    $username = mysqli_real_escape_string($con, $username); //gelen değerden escape karakterleri (',/ vb.) temizler
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);
    // username daha önce kaydolmuş mu diye bakıyoruz
    $query = "SELECT * FROM `users` WHERE username='$username'
                     AND password='" . md5($password) . "'"; //md5 şifreyi veritabanına kaydederken farklı ve zor bir şekilde kaydeder. En güvenli şifreleme yöntemidir.
    $result = mysqli_query($con, $query) or die(mysql_error());
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        $_SESSION['username'] = $username;
        // 
        header("Location:dashboard.php");
    } else {
        header("Location:login.php");
    }
} else {
    
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title>Login</title>
    <script>
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 15px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            background: url(gym.jpg);
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            color: white;
        }
        input, p{
            display: block;
            height: 50px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            color: white;
        }
        ::placeholder{
            color: rgba(255, 255, 255, 0.74);
        }
        input[type='checkbox'] {
            height: 10px;
            width: 10px;

        }
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170" align="left" ></li>
        <li><a href="aboutus.php">ABOUT US</a></li>        
        <li><a href="registration.php">REGISTER NOW</a></li>
        <li><a class="active" href="login.php">LOGIN</a></li>
        <li><a href="">    </a></li>
        <li><a href="">   </a></li>
        <li><a href="">   </a></li>
        <li><a href="">   </a></li>
    </ul>
</div>
<div class="hi" align="center" >
    <form method="post" name="login">
        <table class="" align="center">
            <tr>
                <td></td>
                <td><input type="text" name="username" placeholder="Username" autofocus="true"/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="password" name="password" id="password" placeholder="Password"/></td>
            </tr>
            <tr align="center" >
                <td></td>
                <td><small><input type="checkbox" onclick="myFunction()">Show Password</small></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Login" name="submit"/>
            </tr>
            <br><br><br><br><br>

        </table>
    </form>
</div>    
</body>
</html>