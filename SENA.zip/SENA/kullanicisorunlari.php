<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=GROUP4;charset=utf8", "root", "");
} catch (PDOException $e) {
    echo $e->getMessage();
}


$soru = $db->query("SELECT * FROM `problem`", PDO::FETCH_ASSOC);

//ADMİNE BAĞLAA
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USERS PROBLEMS</title>
</head>
<style>
    body {
        background-color: black;
        color: white;
        font-size: 25px;
    }
    .ana {
        background-color: black;
        box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
        border-radius: 50px 20px;
    }
    #line{
        display: flex;
        align-items: center;
        justify-content: center ;

    }
    #line li{
        list-style: none; /*nokta nokta olmasın diye */
        padding: 0 10px;
    }
    #line li a{
        text-decoration: none;/*çizgi olmasın diye*/
        font-size: 18px;
        font-weight: 500;
        color: white;
    }
    #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
        color: yellow;
    }
    td {
        width: 450px;
        height: 100px;
        font-size: 25px;
    }
    #name, #surname{
        width: 200px;
        text-align: center;
    }
    a {
        text-decoration: none;
    }
</style>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a class="active" href="kullanicisorunlari">USERS PROBLEMS</a></li>
        <li><a href="soruekle.html">ADD QUESTION</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >

    <table border="1"  align="center">
        <br>
        <tr>
            <th>
                Name 
            </th>
            <th>Surname</th>
            <th>Problem</th>
        </tr>
        <div class="iletisim">
            <?php foreach ($soru as $iletisim) {
; ?>
                <tr>
                    <td id="name"><?php echo $iletisim ["name"]; ?></td>
                    <td id="surname"><?php echo $iletisim ["surname"]; ?></td>
                    <td><?php echo $iletisim ["problem"]; ?></td>

                </tr>
<?php } ?>
        </div>
    </table>
</div>
<form action="">
</body>
</html>