<?php
    if($_GET) {

    $name  = $_GET["name"];
    $surname  = $_GET["surname"];
    $problem  = $_GET["problem"];


    }

    try {
        

      $db = new PDO("mysql:host=localhost;dbname=GROUP4;charset=utf8","root",""); 
      } catch (Exception $e) {
       echo $e->getMessage();
}
$data =array (
    "name" => $name,
    "surname" => $surname,
    "problem" => $problem
);
$insert = $db->prepare ("INSERT INTO problem SET name=:name, surname=:surname, problem=:problem"
        );

$result = $insert->execute($data);
if($result) {
    //DIV EKLE dasboarda geri dönsün
echo '<!doctype html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title></title>

    <script></script>

    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            color: white;
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="bmi.php">BODY MASS INDEX</a></li>
        <li><a class="active" href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >
<br><br>
YOUR QUESTION HAS BEEN SENT. <br><br>
IT WILL BE ANSWERED AS SOON AS POSSIBLE
</div>
</body>
</html>
';
} else{
echo '<!doctype html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title></title>

    <script></script>

    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            color: white;
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="bmi.php">BODY MASS INDEX</a></li>
        <li><a class="active" href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >
<br><br>
YOUR QUESTION CAN NOT BE SENT. <br><br>

</div>
</body>
</html>';
}

?>