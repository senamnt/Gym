<?php
    // You must use a database (MYSQL only) in your project. The database (one) must be named after your group number only. ( i.e. “group1”)

//GRUP ADINI DEĞİŞTİRMEYİ UNUTMA! GROUP 4 OLACAK
$con = mysqli_connect("localhost", "root", "", "GROUP4");
    // connectionu check eder
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>