<?php
require('db.php');
// When form submitted, insert values into the database.
if (isset($_REQUEST['username'])) {
    // removes backslashes
    $username = stripslashes($_REQUEST['username']);
    //escapes special characters in a string (< gibi)
    $username = mysqli_real_escape_string($con, $username); //gelen değerden escape karakterleri (',/ vb.) temizler
    $email = stripslashes($_REQUEST['email']);
    $email = mysqli_real_escape_string($con, $email);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);
    $create_datetime = date("Y-m-d H:i:s");
    $query = "INSERT into `users` (username, password, email, create_datetime)
                     VALUES ('$username', '" . md5($password) . "', '$email', '$create_datetime')";
    //md5 şifreyi veritabanına kaydederken farklı ve zor bir şekilde kaydeder. En güvenli şifreleme yöntemidir.
    $result = mysqli_query($con, $query);
    if ($result) {
        echo
        header("Location:dashboard.php");
    } else {
        echo "<div class='form2'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='registration.php'>registration</a></p>
                  </div>";
    }
}
?>

<!doctype html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title>Registration</title>

    <script>
        //yazdığıöız şifreyi gösterir
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }</script>

    <style>
       body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 15px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            background: url(gym.jpg);
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            color: white;
        }
        input, p{
            display: block;
            height: 50px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            color: white;
        }
        ::placeholder{
            color: rgba(255, 255, 255, 0.74);
        }
        input[type='checkbox'] {
            height: 10px;
            width: 10px;

        }

    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170" align="left" ></li>
        <li><a href="aboutus.php">ABOUT US</a></li>        
        <li><a class="active" href="registration.php">REGISTER NOW</a></li>
        <li><a href="login.php">LOGIN</a></li>
        <li><a href="">    </a></li>
        <li><a href="">   </a></li>
        <li><a href="">   </a></li>
        <li><a href="">   </a></li>
    </ul>
</div>
<div class="hi" align="center" >
    <table class="signupp" align="center">
        <tr>
            <td></td>
            <td> 
                <form class="formmm" action="registration.php" method="post">
                    <table class="signup1">
                        <tr>
                            <td height="70"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" class="login-input" name="username" placeholder="Username" required /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" class="login-input" name="email" placeholder="Email Adress"required > </td> 
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                            <input type="password" class="login-input" name="password" id="password" placeholder="Password" required>
                                </td>
                                </tr>    
                                <tr align="center">
                                    <td></td>
                                    <td><input type="checkbox" onclick="myFunction()"><small>Show Password</small></td>
                                    </tr>

                                    <tr>
                                        <td></td>
                                        <td><form method="post" action="dashboard.php"><input type="submit" name="submit" value="Register">                                        
                                            </form></td>
                                    </tr>


                                    </table>
                                    </div>
                                    </body>
                                    </html>
