<?php
//When user register, he has to go login page and must log in. 
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: login.php");
        exit();
    }
?>