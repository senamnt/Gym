<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=GROUP4;charset=utf8","root","");
} catch (PDOException $e) {
    echo $e->getMessage();
}

//Tablodaki cevapları getiriyor
 $soru = $db->query("SELECT * FROM `answer`", PDO::FETCH_ASSOC);
 
 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequently Asked Questions</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script>
        $(document).ready(function () {
            $(".accordion_header").click(function () {
                $(".accordion_header").removeClass("active");
                $(this).addClass("active");
            });
        });

    </script>
    
    <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Muli", sans-serif;
    }
    
    .wrapper {
      width: 1000px;
      margin: 80px auto 0;
      border-radius: 30px;
      overflow: hidden;
    }
    
    .wrapper .accordion_wrap .accordion_header {
      width: 100%;
      /* height: 50px; */
      background: #0f0f0faa;
      padding: 15px;
      color: #39a098;
      font-weight: 700;
      border-bottom: 2px solid #39a098;
      position: relative;
      cursor: pointer;
      text-align: center;
    }
    
    .wrapper .accordion_wrap:first-child .accordion_header {
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    
    .wrapper .accordion_wrap:last-child .accordion_header {
      border-bottom: 2px solid transparent;
      border-bottom-left-radius: 3px;
      border-bottom-right-radius: 3px;
    }
    
    .wrapper .accordion_wrap:last-child .accordion_header:hover {
      border-bottom: 2px solid transparent;
    }
    
    .wrapper .accordion_wrap .accordion_header:before,
    .wrapper .accordion_wrap .accordion_header:after {
      content: "";
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      right: 15px;
      width: 20px;
      height: 2px;
      background: #39a098;
    }
    
    .wrapper .accordion_wrap .accordion_header:hover {
      color: #01645d;
      border-color: #01645d;
    }
    
    .wrapper .accordion_wrap .accordion_header:hover:before,
    .wrapper .accordion_wrap .accordion_header:hover:after {
      background: #01645d;
    }
    
    .wrapper .accordion_wrap .accordion_header:after {
      transform: rotate(-90deg);
      transition: all 0.5s ease;
    }
    
    .wrapper .accordion_wrap .accordion_body {
      width: 100%;
      height: 0px;
      transition: all 0.5s ease;
      background: #ffffff32;
      overflow: hidden;
    }
    
    .wrapper .accordion_wrap .accordion_body p {
      padding: 30px;
      font-size: 15px;
      line-height: 22px;
      color: #fff;
      font-weight: 700;
    }
    
    .wrapper .accordion_wrap .accordion_body ul {
      padding: 30px;
      font-size: 15px;
      line-height: 22px;
      color: #ffff;
      font-weight: 700;
      list-style: none;
    }
    
    .wrapper .accordion_wrap .accordion_header.active {
      color: #01645d;
      border-color: #01645d;
    }
    
    .wrapper .accordion_wrap:last-child .accordion_header.active {
      border-bottom: 2px solid #01645d;
      border-bottom-left-radius: 0px;
      border-bottom-right-radius: 0px;
    }
    
    .wrapper .accordion_wrap .accordion_header.active:before,
    .wrapper .accordion_wrap .accordion_header.active:after {
      background: #01645d;
    }
    
    .wrapper .accordion_wrap .accordion_header.active:after {
      transform: rotate(0deg);
    }
    
    .wrapper .accordion_wrap .accordion_header.active + .accordion_body {
      height: 250px;
      
        
      }
      .btn {
        border: none;
        color: white;
        background-color: #cccccc;
        padding: 10px 20px;
        cursor: pointer;
        border: 2px solid black;
        display: inline-block;
        margin: 0 10px;
        text-decoration: none;
        color: black;
        font-size: large;
        list-style: none; }
      .btn:hover {
        color: black;
        background-color: #fff;
        border: 2px solid black;}
        #ll {
        text-align: right;}

        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        
</style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="bmi.php">BODY MASS INDEX</a></li>
        <li><a href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a class="active" href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
    <div class="wrapper">
       <!-- her soru eklendiğinde htmle tanımlıyor -->
        <?php foreach($soru as $wrapper) { ;?>
        <div class="accordion_wrap accordion_1">
            <div class="accordion_header">
                <h1 style="font: size 20px0px;"><?php echo $wrapper ["question"];?></h1>

            </div>
            <div class="accordion_body">
                <ul>
                    <li><?php echo $wrapper ["answer"];?>
                    </li>
                </ul>
            </div>
        </div>
        <?php } ?>
    </div>
<div align="center">
    <br>
<a href="cwu.php"><button class="btn">ASK QUESTION</button></a>
</div>
</body>

</html>