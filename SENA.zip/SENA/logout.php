<?php
    session_start();
    if(session_destroy()) {
        //When we log out, we'll be in 'about us' page
        header("Location: aboutus.php");
    }
?>