<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title>Login</title>
    <script>
        function myFunction() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 15px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        /*For glowing 'StayFit' (W3schools)*/
        .glow {
            font-size: 40px;
            color: #fff;
            text-align: center;
            animation: glow 1s ease-in-out infinite alternate;
        }

        @-webkit-keyframes glow {
            from {
                text-shadow: 0 0 10px yellow, 0 0 20px yellow, 0 0 30px yellow, 0 0 40px yellow, 0 0 50px yellow, 0 0 60px yellow, 0 0 70px yellow;
            }

            to {
                text-shadow: 0 0 20px gray, 0 0 30px gray, 0 0 40px gray, 0 0 50px gray, 0 0 60px gray, 0 0 70px gray, 0 0 80px gray;
            }

        }
        .hi{
            font-family: cursive;
            font-size: 30px;
            color: gray;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170" align="left" ></li>
        <li><a class="active" href="aboutus.php">ABOUT US</a></li>        
        <li><a href="registration.php">REGISTER NOW</a></li>
        <li><a  href="login.php">LOGIN</a></li>
        <li><a href="">    </a></li>
    </ul>
</div>
<br><br>
<div class="hi" align="center" >
    <!-- ana1.png has done with photopedia (added shadow to corner, changing the color and added the text ) -->
    <img src="ana1.png" align="center" >
        <br>
        Are you afraid of Gym? <br>
        If you say you don't want to leave half again! <br>
        Let's recreate your body together with <i><h1 class="glow"> STAYFIT!</h1></i>

        Remember; Your best clothing is your own body. <br><br><br><br><br>
        </body>
        </html>