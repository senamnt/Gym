<?php

//connect with us page

require('db.php');
// When form submitted, insert values into the database.
if (isset($_REQUEST['name'])) {
    // removes backslashes
    $name = stripslashes($_REQUEST['name']);
    //escapes special characters in a string (< gibi)
    $name = mysqli_real_escape_string($con, $name);
    $surname = stripslashes($_REQUEST['surname']);
    $surname = mysqli_real_escape_string($con, $surname);
    $problem = stripslashes($_REQUEST['problem']);
    $problem = mysqli_real_escape_string($con, $problem);
    $create_datetime = date("Y-m-d H:i:s");
    $query = "INSERT INTO `problem`(`name`, `surname`, `problem`, `create_datetime`)
                     VALUES ('$name', '$surname', '$problem', '$create_datetime')";
    $result = mysqli_query($con, $query);
    if ($result) {
        echo
        "<div class='go'>
                  <h3>Your Message Mas Been Sent.</h3><br/>
                  </div>";
    } else {
        echo "<div class='gogo'>
                  <h3>Required fields are missing.</h3><br/>
                  </div>";
    }
}
?>

<!doctype html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title>PERSONAL TRAINER</title>

    <script></script>

    <style>
               body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            color: white;
        }
        input, p{
            display: block;
            height: 50px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            color: white;
        }
        ::placeholder{
            color: rgba(255, 255, 255, 0.74);
        }
        
        textarea {
            display: block;
            height: 100px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            font-family: Helvetica, sans-serif;
            color: white;
        }
        td{
            width: 500px;
            font-size: 20px;
        }
     
    </style>
</head>
<body>
<div class="ana" align="center">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a  href="bmi.php">BODY MASS INDEX</a></li>
        <li><a href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a class="active" href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >
    <h2>YASİN TÜZEMEN</h2>
    <table align="center" style="width:1500px" >
        <tr>
            <td> <!-- This site (sormspree) ensures that the entered data is sent to our e-mail. It gives us a code (mqknjzzv) when we become a member. With this code, the message entered by the user is sent to the e-mail that owns the code. -->
                <form action="https://formspree.io/f/xdobjbbd" method="post">
                    <table align="center">
                        <tr>
                              <td><img src="yasin.png" height="400" widht="400"></td>
            <td><br>Hello, I'm Yassin. Let's work together to solve your problems in posture problems, strength gain, chronic pain, joint problems, weight gain / loss and healthy nutrition and continue your life in a healthier way. Posture disorders, in particular, are the root cause of more chronic ailments than you might think. Contact me for a healthy posture.</td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><br><br><input type="text" name="name" placeholder="Name" required /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="text" name="surname" placeholder="Surname"required > </td> 
                            </tr>
                            <tr>
                                <td></td>
                                <td>
                            <textarea name="problem" placeholder="Please briefly introduce yourself."<required></textarea>
                                </td>
                                </tr>    
                                <tr>
                                    <td></td>
                                    <td><input type="submit" name="submit" value="Submit">                                        
                                    </td>
                                </tr>
                                     <tr>
                                <td></td>
                                <td><input type="reset" value="Reset"><br></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                </tr>

                                </table>
                    </div>
                                </body>
                                </html>
