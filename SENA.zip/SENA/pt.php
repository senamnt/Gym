<!doctype html>
<html>
    <head>
        <meta charset="utf-8"/>
    <title>Personal Trainer</title>

    <script></script>

    <style>
               body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            color: yellow;
        }
        h2{
            color: white;
        }
        table, th, td {
  border:1px solid white;
  
}

    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a  href="bmi.php">BODY MASS INDEX</a></li>
        <li><a href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a class="active" href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >
    <table align="center">
        <h2>GET A ONLINE PERSONAL TRAINER</h2>
        <h5>With <i>StayFit</i> you can work online with a personal tariner.</h5>
        <tr> 
            <td> 
                    <table style="width:1200px ; height: 1300px">
                        
                        <tr>
                            <td align="center"><img src="senamente.png" height="250" widht="250"></td>
                            <td align="center" >Sena Mente</td>
                            <td align="center">Online <br> İstanbul</td>
                            <td align="center"><a href="sena.php" style="color: yellow" >Contact her!</a></td>
                        </tr>
                        <tr>
                            <td align="center"><img src="semih.png" height="250" widht="250"></td>
                            <td align="center" >Semih İli</td>
                            <td align="center">Online <br> İstanbul</td>
                            <td align="center"><a href="semih.php" style="color: yellow" >Contact him!</a></td>
                        </tr>
                            <tr>
                            <td align="center"><img src="ugur.png" height="250" widht="250"></td>
                            <td align="center" >Uğur Yeşil</td>
                            <td align="center">Online + <br> Ankara</td>
                            <td align="center"><a href="ugur.php" style="color: yellow" >Contact him!</a></td>
                        </tr>   
                        <tr>
                            <td align="center"><img src="yasin.png" height="250" widht="250"></td>
                            <td align="center" >Yasin Tüzemen</td>
                            <td align="center">Online <br> İzmir</td>
                            <td align="center"><a href="yasin.php" style="color: yellow" >Contact him!</a></td>
                        </tr>
                        <tr>
                            <td align="center"><img src="aliatakan.png" height="250" widht="250"></td>
                            <td align="center" >Ali Atakan Bakır</td>
                            <td align="center">Online <br> Kocaeli</td>
                            <td align="center"><a href="aliatakan.php" style="color: yellow" >Contact him!</a></td>
                        </tr>
                                

                                </table>
                    </div>
                                </body>
                                </html>
