<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
    <title>STAYFIT</title>
    <style>
        /*General Settings*/

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        html {
            font-size: 10px;
        }

        body {
            font-family: 'Lato', sans-serif;
            font-size: 1.6rem;
            font-weight: 400;
            line-height: 1.5;
            background-color: #fff;
        }

        h1, h2, h3, h4, h5, h6 {
            font-weight: 700;
            font-family: Montserrat;
        }

        a {
            text-decoration: none;
        }

        ul {
            list-style-type: none;
        }

        .img-fluid {
            max-width: 100%;
            height: auto;
        }

        .clearfix::after {
            content: "";
            display: block;
            clear: both;
        }

        .col {
            float: left;
            width: 100%;
            padding: 1rem;
        }

        .container {
            width: 100%;
            margin-left: auto;
            margin-right: auto;
            padding-left: .5rem;
            padding-right: .5rem;
        }

        /*Responsive Design*/

        @media (min-width: 576px) {

            .container {
                max-width: 540px;
            }

            html{
                font-size: 7px;
            }
        }

        @media (min-width: 768x) {
            .container {
                max-width: 720px;
            }
            html{
                font-size: 8px;
            }
            .col{
                width: 50%;
            }
        }

        @media (min-width: 992px) {
            .container {
                max-width: 960px;
            }
            html{
                font-size: 9px;
            }
            .col{
                width: 33.3333%;
            }
        }

        @media (min-width: 1200px) {
            .container {
                max-width: 1140px;
            }
            html{
                font-size: 10px;
            }

        }

        .text-uppercase {
            text-transform: uppercase;
        }

        section {
            padding-top: 10rem;
            padding-bottom: 10rem;
            text-align: center;
        }

        .btn-large {
            font-size: 2rem;
            padding: 2.2rem 1.6rem;
        }

        .btn {
            margin-top: 4rem;
            font-weight: 400;
            display: inline-block;
            background-color: transparent;
            border: 2px solid transparent;
            color: #ffffff;
            border-radius: .4rem;
            transition: all .5s ease;
        }

        .btn-social {
            width: 5rem;
            height: 5rem;
            border-radius: 50%;
            font-size: 2rem;
            line-height: 2rem;
        }


        .btn-outline {
            color: #fff;
            border-color: #ffffff;
            background-color: transparent;

        }

        .btn-outline:hover {
            color: #212529;
            background-color: #ffffff;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #18BC9C;
            border-color: #18BC9C;
            color: #fff;
            padding: 2.2rem 1.6rem;
        }

        .btn-primary:hover {
            background-color: #128f76;
            border-color: #128f76;
        }

        /* navbar settings*/

        nav{
            width: 100%;
            font-family: Montserrat;
            background-color: black;
            color: #ffffff;
            padding-top: 2.4rem;
            padding-bottom: 2.4rem;
            position: fixed;
            z-index: 500;
        }

        .container > h3{
            color: #B22727;
            margin-top: 50px;
            font-size: 26px;
        }

        #logo-box {
            float: left;
            padding-top: .5rem;
        }

        #logo-box .logo {
            color: #ffffff;
            font-weight: 700;
            font-size: 3.2rem;
        }

        #nav-links {
            float: right;
        }

        #nav-links .nav-item {
            float: left;
            margin: .4rem;
        }


        #nav-links .nav-link {
            color: #fff;
            font-size: 1.6rem;
            font-weight: 700;
            display: block;
            padding: .6rem;
            letter-spacing: .1rem;
            transition: color .3s;
        }

        #nav-links .nav-link:hover {
            color: #FFD369;
        }

        /*header settings*/

        header {
            background-color: #222831;
            padding-top: calc(139px + 10rem);
            padding-bottom: 139px;
            text-align: center;
        }

        header h1 {
            color: #fff;
            font-size: 7.6rem;
        }
        header h2 {
            color: #fff;
            font-size: 2.8rem;
            font-family: 'Lato';
            font-weight: 300;
        }

        hr.star-light {
            border-color: #fff;
        }

        hr.star-dark {
            border-color: #2C3E50;
        }

        .star-light, .star-dark {
            border: none;
            border-top: .4rem solid #fff;
            max-width: 25rem;
            margin: 2.5rem auto auto;
            overflow: visible;
            height: 1px;
        }



        .star-dark::after {
            color: #2C3E50;
            background-color: #ffffff;
        }

        .star-light, .star-dark {
            margin-bottom: 40px;
        }

        #under {
            background-color: #393E46
        }

        #normal {
            background-color: #222831
        }

        #over {
            background-color: #393E46
        }
        a{
            color: #FFF
        }
        a:visited{
            color: #fff;
        }
        /*Portfolio*/

        #portfolio {
            text-align: center;
        }

        #portfolio h2 {
            font-size: 4.8rem;
            color: #2C3E50;
        }


        .portfolio-item {
            position: relative;
            text-align: left;
        }

        .portfolio-item img {
            display: block;
        }

        .img-overlay {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: #FFD369;
            opacity: 0;
            transition: opacity .5s ease;
        }

        .img-overlay .icon {
            color: #ffffff;
            font-size: 2rem;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .portfolio-item:hover .img-overlay {
            opacity: 0.8;
        }



        /*about*/

        #about {
            background-color: #222831;
            color: #ffffff;
        }

        #about h2 {
            font-size: 4.8rem;
        }

        #about-text	{
            text-align: center;
        }

        #about-text .left {
            float: left;
            width: 50%;
            padding-right: 2rem;
            padding-left: 30rem;
        }

        #about-text .right{
            float: right;
            width: 50%;
            padding-left: 2rem;
            padding-right: 30rem;
        }

        #about-text .text {
            font-size: 2rem;
        }


        /*Contact*/

        #contact h2 {
            font-size: 4.8rem;
            color: #2C3E50;
        }

        #contact-form {
            width: 70%;
            margin: 0 auto;
            text-align: left;

        }

        .form-group {
            border-bottom: 1px solid #e9ecef;
            padding-bottom: 2rem;
            margin-bottom: 4rem;
            text-align: left;
        }

        .form-group input, .form-group textarea {
            border: none;
            width: 100%;
            display: block;
            font-size: 2.4rem;
        }

        .form-group input:focus, textarea:focus  {
            outline: 0;
        }

        /*footer*/

        footer {
            padding-top: 6rem;
            padding-bottom: 6rem;
            background-color: #2C3E50;
            color: #FFFFFF;
            text-align: center;

        }

        footer h4 {
            font-size: 2.4rem;
        }

        footer p {
            font-size: 2rem;
            margin-top: 1rem;
        }

        footer li {
            display: inline-block;
            margin-right: 1rem;
        }



    </style>

</head>
<body>
    <nav>
        <div class="container clearfix">
            <div id="logo-box">
                <a href="#" class="logo text-uppercase">
                    STAYFIT
                </a>
            </div>
            <div id="nav-links">
                <ul>
                    <li class="nav-item">
                        <a href="#under" class="nav-link text-uppercase">
                            UNDERWEIGHT
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#normal" class="nav-link text-uppercase">
                            NORMAL
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#over" class="nav-link text-uppercase">
                            OVERWEIGHT
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="bmi.php" class="nav-link text-uppercase">
                            GO BACK
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header>
        <div class="container">
            <img id="profile-image" class="img-fluid" src="alia.png" alt"""> <!--https://besthqwallpapers.com/tr/download/original/15034 -->
                <h1 class="text-uppercase">Start Healthy Life</h1>
                <hr class="star-light">
                <h2>FITNESS MOVES</h2>
                <h3>All movements should be repeated with 3x15 sets</h3>
        </div>
    </header>

<section id="under">
    <div class="container">
        <h2 id="under" class="text-uppercase">
            UNDERWEIGHT
        </h2>
        <hr class="star-dark">
        <div id="portfolio-images" class="clearfix">
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image001.png"> <!-- https://workoutlabs.com/exercise-guide/triceps-pushdowns/-->
                            Tricep Cable Rope Push /Pull Downs
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image003.png"> <!--https://workoutlabs.com/exercise-guide/barbell-bench-press/-->
                            Barbell Bench Press / Chest Press
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image005.png"> <!--https://workoutlabs.com/exercise-guide/seated-machine-leg-extensions/ -->
                            Seated Machine Leg Extensions
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image007.png"> <!--https://workoutlabs.com/exercise-guide/machine-seated-shoulder-press/ -->
                            Machine Seated Shoulder Press
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image009.png"> <!--https://workoutlabs.com/exercise-guide/reverse-crunch/ -->
                            Reverse Crunch
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">

            </div>
        </div>
    </div>
</section>
<section id="normal">
    <div class="container">
        <h2 id="normal" class="text-uppercase">
            NORMAL
        </h2>
        <hr class="star-dark">
        <div id="portfolio-images" class="clearfix">
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image023.png"> <!--https://workoutlabs.com/exercise-guide/cable-curl/ -->
                            Standing Bicep Cable Curls
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image025.png"> <!--https://workoutlabs.com/exercise-guide/pushups/ -->
                            Push-ups / Pushups
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image027.png"> <!--https://workoutlabs.com/exercise-guide/standing-dumbbell-calf-raises/ -->
                            Standing Dumbbell Calf Raises
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image019.png"> <!--https://workoutlabs.com/exercise-guide/seated-dual-front-raises-raises/ -->
                            Seated Dual /Front Raises
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image009.png"> <!--https://workoutlabs.com/exercise-guide/reverse-crunch/ -->
                            Reverse Crunch
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">

            </div>
        </div>
    </div>
</section>
<section id="over">
    <div class="container">
        <h2 id="over" class="text-uppercase">
            OVERWEIGHT
        </h2>
        <hr class="star-dark">
        <div id="portfolio-images" class="clearfix">
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image031.png"> <!--https://workoutlabs.com/exercise-guide/weighted-bench-dips/ -->
                            Weighted Bench Dips
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image042.jpg"> <!--https://workoutlabs.com/exercise-guide/butterfly/ -->
                            Butterflies / Pec Deck / Seated Machine Flyes
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image035.png"> <!--https://workoutlabs.com/exercise-guide/standing-barbell-calf-raises/ -->
                            Standing Barbell Calf Raises
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image037.png"> <!--https://workoutlabs.com/exercise-guide/seated-lateral-shoulder-dumbbell-raise/ -->
                            Seated Lateral / Side Shoulder Dumbbell Raises
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">
                <div class="portfolio-item">
                    <a href="#">
                        <img class="img-fluid" src="img/image039.png"> <!--https://workoutlabs.com/exercise-guide/plank/ -->
                            Plank
                            <div class="img-overlay">
                                <div class="icon">
                                    <i class="fas fa-search-plus fa-3x"></i>
                                </div>
                            </div>
                    </a>
                </div>
            </div>
            <div class="col">

            </div>
        </div>
    </div>
</section>
<section id="about">
    <h2 class="text-uppercase">ABOUT US</h2>
    <hr class="star-light">
    <div id="about-text" class="clearfix">

        <p class="text">
            Our aim is to bring together our athletes and people who have adopted an active lifestyle with quality, reliable products in sports and nutrition. Supporting sports and healthy nutrition is our top priority.
        </p>


    </div>

</section>



</body>
</html>