<?php
//include auth_session.php file on all user panel pages
include("askagain.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
    <title>Dashboard</title>
    <script>
        function calculatebmi() {
            var weight = document.bmi.weight.value
            var height = document.bmi.height.value
            if (weight > 0 && height > 0) {
                var resultbmi = weight / (height / 100 * height / 100)
                document.bmi.index.value = resultbmi
                if (resultbmi < 18.5) {
                    document.bmi.result.value = "Under Weight"
                }
                if (resultbmi > 18.5 && resultbmi < 25) {
                    document.bmi.result.value = "Normal"
                }
                if (resultbmi > 25) {
                    document.bmi.result.value = "Over Weight"
                }
            } else {
                alert("Check Your Weight And Height!")
            }
        }
    </script>
    <style>
        body {
            background-color: black;

        }
        .ana {
            background-color: black;
            box-shadow: 0 19px 38px yellow, 0 15px 12px yellow;
            border-radius: 50px 20px;
        }
        #line{
            display: flex;
            align-items: center;
            justify-content: center ;

        }
        #line li{
            list-style: none; /*nokta nokta olmasın diye */
            padding: 0 10px;
        }
        #line li a{
            text-decoration: none;/*çizgi olmasın diye*/
            font-size: 18px;
            font-weight: 500;
            color: white;
        }
        #line li a:hover,#line li a.active{ /*üzerine gelince renk değiştirme*/
            color: yellow;
        }
        .hi {
            margin-top: 80px;
            font-size: 25px;
            font-weight: 400;
            background: url(gym.jpg);
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            color: white;
        }
        input {
            display: block;
            height: 50px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.692);
            padding:0 30px;
            margin-top: 20px;
            font-size: 17px;
            font-weight: 400;
            color: white;
        }
        a{
            color: yellow;
        }
        ::placeholder{
            color: rgba(255, 255, 255, 0.74);
        }
        input[type='checkbox'] {
            height: 10px;
            width: 10px;

        }
        h2{
            font-size: 26px;
        }
        td{
            font-size: 18px;
        }

    </style>
</head>
<body>
<div class="ana" align="left">
    <ul id="line">
        <li><img id="logo" src="logo.png" height="170" widht="170"></li>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a class="active" href="bmi.php">BODY MASS INDEX</a></li>
        <li><a href="cwu.php">CONTACT WITH US</a></li>
        <li><a href="adminlogin.php">ADMIN</a></li>
        <li><a href="pt.php">PERSONAL TRAINER</a></li>
        <li><a href="askedquestion.php">FREQUENTLY ASKED QUESTIONS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</div>
<div class="hi" align="center" >

    <!-- YAZI TİPİ DÜZELT -->
    <h2 align="center" style="text-transform:uppercase;">Hey<b> <?php echo $_SESSION['username']; ?>,  Calculate Your Body Mass Index! </b></h2>
    <form name="bmi">
        <table id="lala" align="center">
            <tr>
                <td height="0">YOUR HEIGHT<small>(in cm)</small></td>
                <td> <input type="number" name="height" value="Height" placeholder="e.g. 170"></td>
                </tr>

                <tr>
                    <td>YOUR WEIGHT<small>(in kg)</small></td>
                    <td><input type="number" name="weight" value="Weight" placeholder="e.g. 56"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="button" value="CALCULATE" onClick="calculatebmi()"><br></td>
                        </tr>
                        <tr>
                            <td style="text-transform:uppercase;"><?php echo $_SESSION['username']; ?>, YOUR BODY MASS INDEX IS: </td>
                            <td><input type="button" name="index"><br></td>
                            </tr>
                            <tr>
                                <td style="text-transform:uppercase;"><?php echo $_SESSION['username']; ?>, YOU ARE: </td>
                                <td><input style='color: yellow' type="button" name="result"><br></td>
                                </tr>
                                <tr>
                                        <td></td>
                                        <td><ul id="line"><li><a href="alia.php"><b style="font-size: 20px">CLICK TO LEARN HOW TO TRAIN!</b></a></li></ul></td>
                                    </tr>
                                <tr>
                                    <td></td>
                                    <td><input type="reset" value="RESET"><br></td>
                                    </tr>
                                    </table>
                                    </form>
                                    </div>
                                    </body>
                                    </html>